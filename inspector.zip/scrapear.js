const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/', async (req, res) => {

    var MetaInspector = require('metainspector');
    var client = new MetaInspector("https://www.acculabsupplies.com", { timeout: 0 });

    client.on("fetch", function(){
        console.log("Description: " + client.description);

        if (client.title) {
            console.log("title: " + client.title)
        }

        if( client.links ){
            console.log("Links: " + client.links);
        }

        if( client.keywords ){
            console.log("Keywords: "+ client.keywords)
        }

        if( client.url ){
            console.log("url: "+client.url)
        }

        //console.log("Links: " + client.links.join(","));
    });

    client.on("error", function(err){
        console.log(err);
    });

    client.fetch();

})


app.listen(3000, () =>{
    console.log("start server")
});

